<?php
echo "Hello World! This is Lab 6!!";
?>